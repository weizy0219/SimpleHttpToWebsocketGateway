/****************************************************************************
** Meta object code from reading C++ file 'simplehttpserver.h'
**
** Created by: The Qt Meta Object Compiler version 68 (Qt 6.4.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../HttpToWebSocketGateway/simplehttpserver.h"
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'simplehttpserver.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 68
#error "This file was generated using the moc from 6.4.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

#ifndef Q_CONSTINIT
#define Q_CONSTINIT
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
namespace {
struct qt_meta_stringdata_SimpleHttpServer_t {
    uint offsetsAndSizes[30];
    char stringdata0[17];
    char stringdata1[7];
    char stringdata2[1];
    char stringdata3[5];
    char stringdata4[6];
    char stringdata5[15];
    char stringdata6[9];
    char stringdata7[4];
    char stringdata8[15];
    char stringdata9[4];
    char stringdata10[20];
    char stringdata11[23];
    char stringdata12[6];
    char stringdata13[5];
    char stringdata14[9];
};
#define QT_MOC_LITERAL(ofs, len) \
    uint(sizeof(qt_meta_stringdata_SimpleHttpServer_t::offsetsAndSizes) + ofs), len 
Q_CONSTINIT static const qt_meta_stringdata_SimpleHttpServer_t qt_meta_stringdata_SimpleHttpServer = {
    {
        QT_MOC_LITERAL(0, 16),  // "SimpleHttpServer"
        QT_MOC_LITERAL(17, 6),  // "testId"
        QT_MOC_LITERAL(24, 0),  // ""
        QT_MOC_LITERAL(25, 4),  // "int&"
        QT_MOC_LITERAL(30, 5),  // "newId"
        QT_MOC_LITERAL(36, 14),  // "receivePostMsg"
        QT_MOC_LITERAL(51, 8),  // "QString&"
        QT_MOC_LITERAL(60, 3),  // "msg"
        QT_MOC_LITERAL(64, 14),  // "receiveExitCmd"
        QT_MOC_LITERAL(79, 3),  // "cmd"
        QT_MOC_LITERAL(83, 19),  // "onReceiveWsResponse"
        QT_MOC_LITERAL(103, 22),  // "onWsServerStateChanged"
        QT_MOC_LITERAL(126, 5),  // "bool&"
        QT_MOC_LITERAL(132, 4),  // "flag"
        QT_MOC_LITERAL(137, 8)   // "onTestId"
    },
    "SimpleHttpServer",
    "testId",
    "",
    "int&",
    "newId",
    "receivePostMsg",
    "QString&",
    "msg",
    "receiveExitCmd",
    "cmd",
    "onReceiveWsResponse",
    "onWsServerStateChanged",
    "bool&",
    "flag",
    "onTestId"
};
#undef QT_MOC_LITERAL
} // unnamed namespace

Q_CONSTINIT static const uint qt_meta_data_SimpleHttpServer[] = {

 // content:
      10,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags, initial metatype offsets
       1,    1,   50,    2, 0x06,    1 /* Public */,
       5,    1,   53,    2, 0x06,    3 /* Public */,
       8,    1,   56,    2, 0x06,    5 /* Public */,

 // slots: name, argc, parameters, tag, flags, initial metatype offsets
      10,    1,   59,    2, 0x0a,    7 /* Public */,
      11,    1,   62,    2, 0x0a,    9 /* Public */,
      14,    1,   65,    2, 0x08,   11 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, QMetaType::QString,    9,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 12,   13,
    QMetaType::Void, 0x80000000 | 3,    4,

       0        // eod
};

Q_CONSTINIT const QMetaObject SimpleHttpServer::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_SimpleHttpServer.offsetsAndSizes,
    qt_meta_data_SimpleHttpServer,
    qt_static_metacall,
    nullptr,
    qt_incomplete_metaTypeArray<qt_meta_stringdata_SimpleHttpServer_t,
        // Q_OBJECT / Q_GADGET
        QtPrivate::TypeAndForceComplete<SimpleHttpServer, std::true_type>,
        // method 'testId'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int &, std::false_type>,
        // method 'receivePostMsg'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'receiveExitCmd'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString, std::false_type>,
        // method 'onReceiveWsResponse'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<QString &, std::false_type>,
        // method 'onWsServerStateChanged'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<bool &, std::false_type>,
        // method 'onTestId'
        QtPrivate::TypeAndForceComplete<void, std::false_type>,
        QtPrivate::TypeAndForceComplete<int &, std::false_type>
    >,
    nullptr
} };

void SimpleHttpServer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SimpleHttpServer *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->testId((*reinterpret_cast< std::add_pointer_t<int&>>(_a[1]))); break;
        case 1: _t->receivePostMsg((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1]))); break;
        case 2: _t->receiveExitCmd((*reinterpret_cast< std::add_pointer_t<QString>>(_a[1]))); break;
        case 3: _t->onReceiveWsResponse((*reinterpret_cast< std::add_pointer_t<QString&>>(_a[1]))); break;
        case 4: _t->onWsServerStateChanged((*reinterpret_cast< std::add_pointer_t<bool&>>(_a[1]))); break;
        case 5: _t->onTestId((*reinterpret_cast< std::add_pointer_t<int&>>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SimpleHttpServer::*)(int & );
            if (_t _q_method = &SimpleHttpServer::testId; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SimpleHttpServer::*)(QString & );
            if (_t _q_method = &SimpleHttpServer::receivePostMsg; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (SimpleHttpServer::*)(QString );
            if (_t _q_method = &SimpleHttpServer::receiveExitCmd; *reinterpret_cast<_t *>(_a[1]) == _q_method) {
                *result = 2;
                return;
            }
        }
    }
}

const QMetaObject *SimpleHttpServer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SimpleHttpServer::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SimpleHttpServer.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int SimpleHttpServer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<QMetaType *>(_a[0]) = QMetaType();
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void SimpleHttpServer::testId(int & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SimpleHttpServer::receivePostMsg(QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SimpleHttpServer::receiveExitCmd(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
